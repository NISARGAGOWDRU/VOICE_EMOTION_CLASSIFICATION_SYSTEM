# VOICE-EMOTION-CLASSIFICATION-SYSTEM
 Built a python application that analyses the sentiment behind the tone of the voice and predicts the Sentiment involved
